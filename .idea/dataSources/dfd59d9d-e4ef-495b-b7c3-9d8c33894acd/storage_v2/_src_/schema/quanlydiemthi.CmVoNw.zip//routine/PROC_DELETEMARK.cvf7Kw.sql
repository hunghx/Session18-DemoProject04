create
    definer = root@localhost procedure PROC_DELETEMARK(IN studentId varchar(4), OUT num_deleted int)
BEGIN
    DECLARE count_deleted INT DEFAULT 0;
    WHILE (EXISTS (SELECT 1 FROM mark WHERE studentId = studentId)) DO
        DELETE FROM mark WHERE studentId = studentId;
        SET count_deleted = count_deleted + 1;
    END WHILE;
    SET num_deleted = count_deleted;
END;


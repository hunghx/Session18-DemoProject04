create
    definer = root@localhost procedure PROC_DELETEMARK(IN m_studentId varchar(4), OUT m_SoBanGhiDaXoa int)
BEGIN
    set m_SoBanGhiDaXoa=(select count(*) from mark
    WHERE studentId = m_studentId);
     DELETE FROM mark
    WHERE studentId = m_studentId ;
END;


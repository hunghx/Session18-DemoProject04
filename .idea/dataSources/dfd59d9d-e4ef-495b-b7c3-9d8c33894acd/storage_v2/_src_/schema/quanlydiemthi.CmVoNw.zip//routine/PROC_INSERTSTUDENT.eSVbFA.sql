create
    definer = root@localhost procedure PROC_INSERTSTUDENT(IN studentId int, IN studentName varchar(255),
                                                          IN birthday date, IN gender varchar(10),
                                                          IN address varchar(255), IN phoneNumber varchar(45))
BEGIN
    -- Câu lệnh INSERT
    INSERT INTO STUDENT (studentId, studentName,birthday, gender, address,phoneNumber)
    VALUES (studentId, studentName,birthday, gender, address,phoneNumber);
  
END;


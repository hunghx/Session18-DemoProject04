create
    definer = root@localhost procedure PROC_UPDATESUBJECT(IN subjectId varchar(255), IN subjectName varchar(255))
BEGIN
    UPDATE SUBJECT
    SET subjectName = SUBJECT.subjectName
    WHERE SUBJECT.subjectId = subjectId;
END;


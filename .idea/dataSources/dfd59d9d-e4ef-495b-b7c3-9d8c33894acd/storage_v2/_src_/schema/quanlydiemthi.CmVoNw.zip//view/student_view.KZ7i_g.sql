create definer = root@localhost view student_view as
select `quanlydiemthi`.`student`.`studentId`   AS `studentId`,
       `quanlydiemthi`.`student`.`studentName` AS `studentName`,
       `quanlydiemthi`.`student`.`gender`      AS `gender`,
       `quanlydiemthi`.`student`.`address`     AS `address`
from `quanlydiemthi`.`student`;

